import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {
   public static void main(String[] args) {
      //ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");

      AbstractApplicationContext context = 
          new ClassPathXmlApplicationContext("Beans.xml");
      
      //context.start();
      
      HelloWorld obj = (HelloWorld) context.getBean("helloWorld");
      obj.setMessage("I am Singelton");
      obj.getMessage();
      HelloWorld obj1 = (HelloWorld) context.getBean("helloWorld");
      //obj1.setMessage("I am Not");
      obj1.getMessage();
      
      
      HelloWorldInheritance objA = (HelloWorldInheritance) context.getBean("helloWorldInheritance");

      objA.getMessage1();
      objA.getMessage2();

      HelloIndia objB = (HelloIndia) context.getBean("helloIndia");
      objB.getMessage1();
      objB.getMessage2();
      objB.getMessage3();
      
      
      
      context.registerShutdownHook();
   }
}